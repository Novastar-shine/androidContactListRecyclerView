package com.example.kanykey_contactlist;

import android.content.Context;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    LayoutInflater inflater;
    List<Contact> contacts;
    private RecyclerViewClickListener listener;
    Context context;
    public Adapter(Context context, List<Contact> contacts, RecyclerViewClickListener listener){
        this.inflater = LayoutInflater.from(context);
        this.contacts = contacts;
        this.listener = listener;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.custom_list_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.namelbl.setText(contacts.get(position).getName());
        holder.phonelbl.setText(contacts.get(position).getPhone());
        Picasso.get().load(contacts.get(position).getPhotoUrl()).into(holder.photo);

    }

    @Override
    public int getItemCount() {
        return contacts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView namelbl, phonelbl;
        ImageView photo;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            namelbl= itemView.findViewById(R.id.nameLbl);
            phonelbl = itemView.findViewById(R.id.phoneLbl);
            photo = itemView.findViewById(R.id.img);

            itemView.setOnClickListener(this);
            itemView.findViewById(R.id.callbtn).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:"+contacts.get(getAdapterPosition()).getPhone()));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
            itemView.findViewById(R.id.emailbtn).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_SENDTO);
                    intent.setData(Uri.parse("sms:"+contacts.get(getAdapterPosition()).getPhone()));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        }

        @Override
        public void onClick(View v) {
            listener.onClick(v,getAdapterPosition());
        }

    }
    public interface RecyclerViewClickListener{
        void onClick(View v, int position);
    }
}
