package com.example.kanykey_contactlist;

import java.util.Comparator;

public class Contact {
    private String phone;
    private int age;
    private String name;
    private String gender;
    private String company;
    private String email;
    private String photoUrl;

    public Contact(String phone, int age, String name, String gender, String company, String email, String photoUrl) {
        this.phone = phone;
        this.age = age;
        this.name = name;
        this.gender = gender;
        this.company = company;
        this.email = email;
        this.photoUrl = photoUrl;
    }
    public static Comparator<Contact> contactNameComparatorAZ = new Comparator<Contact>() {
        @Override
        public int compare(Contact o1, Contact o2) {
            return o1.getName().compareTo(o2.getName());
        }
    };
    public static Comparator<Contact> contactNameComparatorZA = new Comparator<Contact>() {
        @Override
        public int compare(Contact o1, Contact o2) {
            return o2.getName().compareTo(o1.getName());
        }
    };

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }
}
