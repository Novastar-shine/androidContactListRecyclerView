package com.example.kanykey_contactlist;



import static com.example.kanykey_contactlist.MainActivity.adapter;
import static com.example.kanykey_contactlist.MainActivity.contacts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

public class ModifyContactActivity extends AppCompatActivity implements View.OnClickListener{
    EditText phoneedit, nameedit, companyedit, emailedit,ageedit,genderedit;
    ImageView modifyImage;
    Button savebtn;
    String phone, company,name,email,gender,photoUrl;
    int age, position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_contact);
        initialize();
        Bundle extras = getIntent().getExtras();
        if(extras != null){
            phone = extras.getString("phone");
            age = extras.getInt("age");
            company = extras.getString("company");
            name = extras.getString("name");
            email = extras.getString("email");
            gender = extras.getString("gender");
            photoUrl= extras.getString("photoUrl");
            position=extras.getInt("position");
        }
        phoneedit.setText(phone);
        nameedit.setText(name);
        companyedit.setText(company);
        genderedit.setText(gender);
        emailedit.setText(email);
        ageedit.setText(Integer.toString(age));
        Picasso.get().load(photoUrl).into(modifyImage);
        savebtn=findViewById(R.id.savebtn);
        savebtn.setOnClickListener(this);
    }

    private void initialize() {
        phoneedit=findViewById(R.id.phoneedit);
        nameedit=findViewById(R.id.nameedit);
        companyedit=findViewById(R.id.companyedit);
        genderedit=findViewById(R.id.genderedit);
        emailedit=findViewById(R.id.emailedit);
        ageedit=findViewById(R.id.ageedit);
        modifyImage=findViewById(R.id.modifyImage);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.savebtn:
                saveContact();
                break;
        }
    }

    private void saveContact() {
        Contact updatedContact = new Contact(
                phoneedit.getText().toString(),Integer.parseInt(ageedit.getText().toString()),
                nameedit.getText().toString(),
                genderedit.getText().toString(),
                companyedit.getText().toString(),
                emailedit.getText().toString(),
                photoUrl);
        contacts.set(position,updatedContact);
        adapter.notifyDataSetChanged();
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

}