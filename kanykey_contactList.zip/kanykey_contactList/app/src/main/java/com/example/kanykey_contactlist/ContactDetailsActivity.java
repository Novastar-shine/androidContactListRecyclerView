package com.example.kanykey_contactlist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class ContactDetailsActivity extends AppCompatActivity implements View.OnClickListener{
    ImageView imageView;
    TextView phonelbl,agelbl,companylbl,namelbl,emaillbl,genderlbl;
    Button modifybtn;
    String phone,company, name, email, gender, photoUrl;
    int age,position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_details);
        initialize();
        Bundle extras = getIntent().getExtras();
        if(extras != null){
            phone = extras.getString("phone");
            age = extras.getInt("age");
            company = extras.getString("company");
            name = extras.getString("name");
            email = extras.getString("email");
            gender = extras.getString("gender");
            photoUrl= extras.getString("photoUrl");
            position=extras.getInt("position");
            setInfo();

        }
    }

    private void setInfo() {
        namelbl.setText(name);
        Picasso.get().load(photoUrl).into(imageView);
        emaillbl.setText(" "+email);
        companylbl.setText(" Company: " + company);
        genderlbl.setText(" Gender: "+gender);
        phonelbl.setText(" "+phone);
        agelbl.setText("  Age: "+Integer.toString(age));
    }

    private void initialize() {
        imageView=findViewById(R.id.imageView);
        phonelbl=findViewById(R.id.phonelbl);
        agelbl=findViewById(R.id.agelbl);
        companylbl=findViewById(R.id.companylbl);
        namelbl=findViewById(R.id.namelbl);
        emaillbl=findViewById(R.id.emaillbl);
        genderlbl=findViewById(R.id.genderlbl);
        modifybtn = findViewById(R.id.modifybtn);
        modifybtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.modifybtn:
                modifyInfo();
                break;
        }
    }

    private void modifyInfo() {
        Intent intent = new Intent(this,ModifyContactActivity.class);
        intent.putExtra("phone",phone);
        intent.putExtra("age",age);
        intent.putExtra("name",name);
        intent.putExtra("gender",gender);
        intent.putExtra("company",company);
        intent.putExtra("email",email);
        intent.putExtra("photoUrl",photoUrl);
        intent.putExtra("position",position);
        startActivity(intent);
    }

}