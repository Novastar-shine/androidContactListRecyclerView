package com.example.kanykey_contactlist;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    static List<Contact> contacts;
    private Adapter.RecyclerViewClickListener listener;
    private static String JSON_URL = "https://raw.githubusercontent.com/Novastar-shine/fakeApiContact/main/ContactJson";
    static Adapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
        new ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(recyclerView);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.sort_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_aToz:
                Collections.sort(contacts,Contact.contactNameComparatorAZ);
                adapter.notifyDataSetChanged();
                return true;
            case R.id.menu_zToA:
                Collections.sort(contacts,Contact.contactNameComparatorZA);
                adapter.notifyDataSetChanged();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void initialize() {
        recyclerView=findViewById(R.id.contactList);
        contacts = new ArrayList<>();
        extractContact();
    }
    private void extractContact() {
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, JSON_URL, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject contactObject = response.getJSONObject(i);
                        Contact contact = new Contact(contactObject.getString("phone").toString(),
                                contactObject.getInt("age"),
                                contactObject.getString("name").toString(),
                                contactObject.getString("gender").toString(),
                                contactObject.getString("company").toString(),
                                contactObject.getString("email").toString(),
                                contactObject.getString("photo"));
                        contacts.add(contact);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                setOnClickListener();
                recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                recyclerView.setHasFixedSize(true);
                adapter= new Adapter(getApplicationContext(),contacts, listener);
                recyclerView.setAdapter(adapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("tag", "onErrorResponse: "+error.getMessage());
            }
        });
        queue.add(jsonArrayRequest);
    }
    private void setOnClickListener() {
        listener= new Adapter.RecyclerViewClickListener() {
            @Override
            public void onClick(View v, int position) {
                Intent intent = new Intent(getApplicationContext(),ContactDetailsActivity.class);
                intent.putExtra("phone",contacts.get(position).getPhone().toString());
                intent.putExtra("age",contacts.get(position).getAge());
                intent.putExtra("name",contacts.get(position).getName().toString());
                intent.putExtra("gender",contacts.get(position).getGender().toString());
                intent.putExtra("company",contacts.get(position).getCompany().toString());
                intent.putExtra("email",contacts.get(position).getEmail().toString());
                intent.putExtra("photoUrl",contacts.get(position).getPhotoUrl());
                intent.putExtra("position",position);
                startActivity(intent);
            }
        };
    }
    ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.RIGHT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }
        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Delete Contact");
            builder.setMessage("Are you sure you wish to delete contact?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    contacts.remove(viewHolder.getAdapterPosition());
                    adapter.notifyDataSetChanged();
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    adapter.notifyDataSetChanged();
                }
            });
            builder.show();
        }
    };
}